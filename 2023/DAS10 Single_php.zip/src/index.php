<!DOCTYPE html>
 <html>
 <head>
 <style>
 img {
 max-width: 200px;
 max-height: 200px;
 }
 </style>
 <title>revenge to siranai.php
 
 
 </title>
 
 </head>
 <body>
 
 <h5>
 This is my wife.She is from Imagination.
 And I,use her name as my id.
 </h5>
 <img src="mywife.png" alt="this is my wife">
 <p>I have been single dog for 19 years.<br>
 One day, my brothers betrayed the singles organization.<br>
 S* and B* ,both of them have the kanozyo.<br>
 Now revenge to them!!!!!<br>
 use '$_GET['LuckyE'](__FILE__);' to begin your revenge!!<br>
 </p>
 </body>
 </html>
 <?php
 error_reporting(0);
 class siroha{
 public $koi;
 
 public function __destruct(){
 $this->koi['zhanjiangdiyishenqing']();
 }
 }
 $kanozyo = $_GET['LuckyE'](__FILE__);
 var_dump($kanozyo);
 $suki = unserialize($_POST['suki']);
